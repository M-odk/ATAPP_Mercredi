﻿using Manufaktura.Controls.Extensions;
using Manufaktura.Controls.Model;
using Manufaktura.Controls.Parser;
using Manufaktura.Controls.SMuFL;
using Manufaktura.Music.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Test_mAN
{
    class MaNote
    {
        private Pitch _hauteur;
        private string _nom;

        public Pitch Hauteur { get => _hauteur; set => _hauteur = value; }
        public string Nom { get => _nom; set => _nom = value; }

        public MaNote(Pitch hauteur , string nom )
        {
            _hauteur = hauteur;
            _nom = nom;
        }

      

    }
}
