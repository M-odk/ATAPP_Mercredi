﻿
namespace Test_mAN
{
    partial class ScoreForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.noteViewer1 = new Manufaktura.Controls.WinForms.NoteViewer();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // noteViewer1
            // 
            this.noteViewer1.DataSource = null;
            this.noteViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.noteViewer1.Location = new System.Drawing.Point(0, 0);
            this.noteViewer1.Name = "noteViewer1";
            this.noteViewer1.RenderingMode = Manufaktura.Controls.Rendering.ScoreRenderingModes.AllPages;
            this.noteViewer1.Size = new System.Drawing.Size(1199, 1000);
            this.noteViewer1.TabIndex = 0;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(547, 186);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(595, 730);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // ScoreForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 1000);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.noteViewer1);
            this.Name = "ScoreForm";
            this.Text = "ScoreForm";
            this.ResumeLayout(false);

        }

        private Manufaktura.Controls.WinForms.NoteViewer noteViewer1;

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}