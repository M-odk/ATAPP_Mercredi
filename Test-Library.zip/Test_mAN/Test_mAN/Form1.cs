﻿using Manufaktura.Controls.Extensions;
using Manufaktura.Controls.Model;
using Manufaktura.Controls.Model.Collections;
using Manufaktura.Controls.Parser;
using Manufaktura.Controls.SMuFL;
using Manufaktura.Music.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Test_mAN.Properties;

namespace Test_mAN
{
    public partial class Form1 : Form
    {
        EnsembleGamme gammes;
        Transposeur transposeur;
      

        // Accès au dossier Assets de l'exe 
        private string assetPath = Path.Combine(Application.StartupPath, "Assets");
        private string fontFileMetaPath = "bravura_metadata.json";
        private string fontFilePath = "Bravura.otf";


        public Form1()
        {
            InitializeComponent();
            //noteViewer1.Settings.IsMusicPaperMode = true; --> était dans l'exemple, ne sait pas a quoi ca sert

            gammes = new EnsembleGamme();
            

            // pour afficher les gammes majeures au départ
            AfficherNotesDansCombobox(false);

            // Créer le dossier Assets s'il est inexistant
            if (!Directory.Exists(assetPath))
            {
                Directory.CreateDirectory(assetPath);
                // créer les fichiers qui contiennent les fonts
                File.WriteAllText(Path.Combine(assetPath, fontFileMetaPath), Resources.bravura_metadata);
                File.WriteAllBytes(Path.Combine(assetPath, fontFilePath), Resources.Bravura);
            }

            // récupérer les ressources fonts pour pouvoir les utiliser dans le noteViewer
            var fontPath = Path.Combine(assetPath, fontFilePath);
            var metaPath = Path.Combine(assetPath, fontFileMetaPath);
            var smuflProfile = SMuFLMusicFont.CreateFromJsonString(File.ReadAllText(metaPath));
            noteViewer1.SetFontFromPath(fontPath, smuflProfile);

            #region Exemple

           // Création d'une portée en clef de sol (G) 
           // Récupérer l'armature --> MajorScale.D
            Score mScore = Score.CreateOneStaffScore(Clef.Treble, Manufaktura.Music.Model.MajorAndMinor.MajorScale.A);

            // Chiffrage dans l'armature (temps de chaque mesure)  
            mScore.FirstStaff.AddTimeSignature(TimeSignatureType.Numbers, 4, 4);
            // Ajout d'une note (sol , blanche) 
            mScore.FirstStaff.AddNote(Pitch.Fb1, RhythmicDuration.Half);
            mScore.FirstStaff.AddNote(Pitch.Fb2, RhythmicDuration.Half);
            mScore.FirstStaff.AddNote(Pitch.Fb3, RhythmicDuration.Half);
            mScore.FirstStaff.AddNote(Pitch.F1, RhythmicDuration.Quarter);
            mScore.FirstStaff.AddNote(Pitch.F2, RhythmicDuration.Quarter);
            mScore.FirstStaff.AddNote(Pitch.F3, RhythmicDuration.Quarter);
            mScore.FirstStaff.AddNote(Pitch.F4, RhythmicDuration.Quarter);

            // Ajout d'un silence 
            mScore.FirstStaff.Add(new Rest(RhythmicDuration.Quarter));
            // Ajout d'une note à partir de sa fréquence en MIDI (60 = Do) qui dure une blanche
            mScore.FirstStaff.AddNote(Pitch.FromMidiPitch(60, Pitch.MidiPitchTranslationMode.Auto), RhythmicDuration.Half);
            // Ajout d'une barre verticale qui sépare les mesures 
            mScore.FirstStaff.AddBarline(BarlineStyle.Regular);
            mScore.FirstStaff.AddNote(Pitch.G4, RhythmicDuration.Quarter);


            mScore.FirstStaff.AddNote(Pitch.FromMidiPitch(61, Pitch.MidiPitchTranslationMode.Auto), RhythmicDuration.Quarter);
            // Ajout de 2 notes superposées (se jouent en même temps) --> MakeChords() 
            mScore.FirstStaff.AddRange(new Note[] {
                    Note.FromMidiPitch(63, RhythmicDuration.Quarter),
                    Note.FromMidiPitch(67, RhythmicDuration.Quarter)
            }.MakeChord());
            mScore.FirstStaff.AddBarline(BarlineStyle.Regular);
            // Ajout de notes liées ensembles
            mScore.FirstStaff.AddRange(StaffBuilder.FromPitches(
                Pitch.C4,
                Pitch.E4,
                Pitch.G4,
                Pitch.A4,
                Pitch.C4,
                Pitch.E4,
                Pitch.G4, // choix de la durée (croches, double croches etc..), le sens de la tige, et comment les lier (Rebeam)
                Pitch.A4).AddUniformRhythm(RhythmicDuration.Sixteenth).ApplyStemDirection(VerticalDirection.Up).Rebeam());

            #region Triolet

            Note n1 = new Note();
            // Mib
            n1.ApplyMidiPitch(63);
            n1.Duration = RhythmicDuration.Quarter;



            n1.Tuplet = TupletType.Start;
            n1.TupletWeightOverride = 1; // Calcul pour l'affichage
            mScore.FirstStaff.Add(n1);

            n1 = new Note();
            n1.ApplyMidiPitch(66);

            n1.Duration = RhythmicDuration.Quarter;
            n1.TupletWeightOverride = 1;

            mScore.FirstStaff.Add(n1);

            n1 = new Note();
            n1.ApplyMidiPitch(66);
            n1.Duration = RhythmicDuration.Quarter;
            n1.TupletWeightOverride = 1;

            n1.Tuplet = TupletType.Stop;
            mScore.FirstStaff.Add(n1);
            #endregion

            mScore.FirstStaff.AddBarline(BarlineStyle.Regular);

            // Après ajout de la barre, on fait un saut de ligne (ajoute la clé, l'armature etc) 
            PrintSuggestion ps = new PrintSuggestion
            {
                IsSystemBreak = true
            };

            mScore.FirstStaff.Add(ps);

            // Permet d'ajouter plusieurs notes avec leur durée en une fois
            mScore.FirstStaff.AddRange(StaffBuilder.FromPitches(Pitch.G4, Pitch.B4, Pitch.D5, Pitch.C4, Pitch.E4, Pitch.G4, Pitch.D4, Pitch.DSharp4, Pitch.A4)
                .AddRhythm("8 8 8 8 4 4 4 4 4"));
            mScore.FirstStaff.AddBarline(BarlineStyle.Regular);

            mScore.FirstStaff.AddRange(StaffBuilder.FromPitches(Pitch.G4, Pitch.B4, Pitch.D5, Pitch.C4, Pitch.E4, Pitch.G4, Pitch.D4, Pitch.DSharp4, Pitch.A4)
                .AddRhythm("8 8 8 8 4 4 4 4 4"));

            mScore.FirstStaff.Elements.Add(new Barline()); // différente manière d'ajouter une barre

            // saut de ligne
            mScore.FirstStaff.Add(new PrintSuggestion() { IsSystemBreak = true });

            // double barre 
            mScore.FirstStaff.AddBarline(BarlineStyle.LightHeavy);

            mScore.FirstStaff.Elements.Add(new TimeSignature(TimeSignatureType.Numbers, 3, 4));
            // TieType permet de faire une liaison entre les notes 
            // AddDots permet de faire une note pointée 
            mScore.FirstStaff.Elements.Add(new Note(Pitch.C4, RhythmicDuration.Half.AddDots(1)) { TieType = NoteTieType.Start });

            mScore.FirstStaff.Elements.Add(new Barline());
            mScore.FirstStaff.Elements.Add(new Note(Pitch.C4, RhythmicDuration.Half.AddDots(1)) { TieType = NoteTieType.Stop });
            mScore.FirstStaff.Elements.Add(new Barline());
            mScore.FirstStaff.Elements.Add(new Note(Pitch.C4, RhythmicDuration.Half.AddDots(1)));
            mScore.FirstStaff.Elements.Add(new Barline(BarlineStyle.LightHeavy));
            #endregion

            noteViewer1.DataSource = mScore;
            transposeur = new Transposeur();
           

            noteViewer1.Refresh();
        }

        /// <summary>
        /// Récupère un fichier musicXml puis le transforme en objet Csharp
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "MusicXml (*.musicxml)|*.musicxml";

            // Récupérer le fichier .musicXml pour l'utiliser 
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                MusicXmlParser parser = new MusicXmlParser();
                Score score = parser.Parse(XDocument.Parse(File.ReadAllText(dialog.FileName)));

                // récupérer la note de référence qui permet d'afficher l'armature 
                MusicalSymbol FirstElements = score.FirstStaff.Elements[0];
                // cast pour pouvoir accéder à Pitch qui est dans Clef
                Clef clef = FirstElements as Clef;
                transposeur.TrouverTonaliteDeDepart(clef.Pitch);

               
                // Affichage 
                noteViewer1.DataSource = score;
                noteViewer1.Refresh();
            }
        }


        /// <summary>
        /// Lorsque la checkbox est checked, la liste déroulante propose les gammes relatives mineures
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ckbMinor_CheckedChanged(object sender, EventArgs e)
        {
            //bool mineur = ckbMinor.Checked;

            //AfficherNotesDansCombobox(mineur);
        }

        /// <summary>
        /// Affichage des gammes dans la combobox
        /// </summary>
        /// <param name="mineur">Savoir si l'affichage doit contenir les gammes mineures ou majeures</param>
        public void AfficherNotesDansCombobox(bool mineur)
        {
            // vider les comboboxs
            cmbGammes.Items.Clear();

            // récupérer les noms des gammes pour les afficher 
            foreach (var gamme in gammes.DGammesMajeures)
            {
                string nomGamme = gamme.Value.Nom;
                string armature = gamme.Key;
                string addToCmb = nomGamme + " : " + armature;

                cmbGammes.Items.Add(addToCmb);
            }
        }

        private void cmbGammes_SelectedIndexChanged(object sender, EventArgs e)
        {
            // récupérer l'entrée utilisateur
           transposeur.RecupererTonaliteDeTransposition(cmbGammes.SelectedItem.ToString());
          
        }


        private void btnTransposer_Click(object sender, EventArgs e)
        {
            // Appeler la méthode dans classe Transposeur
        }

    }
}
