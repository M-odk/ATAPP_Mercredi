﻿using Manufaktura.Controls.Extensions;
using Manufaktura.Controls.Model;
using Manufaktura.Controls.Parser;
using Manufaktura.Controls.SMuFL;
using Manufaktura.Music.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Test_mAN
{
    class Gamme
    {
        // variables
        private List<MaNote> _notes;
        private string _nom;

        // Propriétés
        public List<MaNote> Notes { get => _notes; set => _notes = value; }
        public string Nom { get => _nom; set => _nom = value; }

        // Constructeurs
        public Gamme(string nom, List<MaNote> notes)
        {
            _nom = nom;
            _notes = notes;
        }



    }
}
