﻿using Manufaktura.Controls.Extensions;
using Manufaktura.Controls.Model;
using Manufaktura.Controls.Parser;
using Manufaktura.Controls.SMuFL;
using Manufaktura.Music.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Test_mAN
{
    class EnsembleGamme
    {
        #region Variables MaNote

        /*
        -D = dièse
        -B = bémol
        -DD = + 1 ton
        -BB = - 1 ton
        */

        // Do
        MaNote SiD;
        MaNote Do;
        MaNote ReBB;

        MaNote SiDD;
        MaNote DoD;
        MaNote ReB;
        // Re
        MaNote DoDD;
        MaNote Re;
        MaNote MiBB;

        MaNote ReD;
        MaNote MiB;
        MaNote FaBB;
        // Mi
        MaNote ReDD;
        MaNote Mi;
        MaNote FaB;
        // Fa
        MaNote MiD;
        MaNote Fa;
        MaNote SolBB;

        MaNote MiDD;
        MaNote FaD;
        MaNote SolB;
        // Sol
        MaNote FaDD;
        MaNote Sol;
        MaNote LaBB;

        MaNote FaDDD;
        MaNote SolD;
        MaNote LaB;
        MaNote SiBBB;

        // La
        MaNote SolDD;
        MaNote La;
        MaNote SiBB;

        MaNote DoBB;
        MaNote LaD;
        MaNote SiB;
        // Si
        MaNote LaDD;
        MaNote Si;
        MaNote DoB;


        #endregion

        #region Variables List<MaNote>
        /* Liste des Gammes Majeures */
        List<MaNote> LstGM_Fab; // 8 b
        List<MaNote> LstGM_Dob;
        List<MaNote> LstGM_Solb;
        List<MaNote> LstGM_Reb;
        List<MaNote> LstGM_Lab;
        List<MaNote> LstGM_Mib;
        List<MaNote> LstGM_Sib;
        List<MaNote> LstGM_Fa; // 1 b
        List<MaNote> LstGM_Do; // 0 altération
        List<MaNote> LstGM_Sol; // 1 #
        List<MaNote> LstGM_Re;
        List<MaNote> LstGM_La;
        List<MaNote> LstGM_Mi;
        List<MaNote> LstGM_Si;
        List<MaNote> LstGM_FaD;
        List<MaNote> LstGM_DoD;
        List<MaNote> LstGM_SolD; // 8 #


        ///* Liste des Gammes Mineures */
        //List<MaNote> LstGmin_Reb; // 8 b
        //List<MaNote> LstGmin_Lab;
        //List<MaNote> LstGmin_Mib;
        //List<MaNote> LstGmin_Sib;
        //List<MaNote> LstGmin_Fa;
        //List<MaNote> LstGmin_Do;
        //List<MaNote> LstGmin_Sol;
        //List<MaNote> LstGmin_Re; // 1 b
        //List<MaNote> LstGmin_La; // 0 altération
        //List<MaNote> LstGmin_Mi; // 1 #
        //List<MaNote> LstGmin_Si;
        //List<MaNote> LstGmin_FaD;
        //List<MaNote> LstGmin_DoD;
        //List<MaNote> LstGmin_SolD;
        //List<MaNote> LstGmin_ReD;
        //List<MaNote> LstGmin_LaD;
        //List<MaNote> LstGmin_MiD; // 8 #
        #endregion

        #region Gammes

        Gamme maj_Fab;
        Gamme maj_Dob;
        Gamme maj_Solb;
        Gamme maj_Reb;
        Gamme maj_Lab;
        Gamme maj_Mib;
        Gamme maj_Sib;
        Gamme maj_Fa;
        Gamme maj_Do;
        Gamme maj_Sol;
        Gamme maj_Re;
        Gamme maj_La;
        Gamme maj_Mi;
        Gamme maj_Si;
        Gamme maj_FaD;
        Gamme maj_DoD;
        Gamme maj_SolD;


        //Gamme min_Reb;
        //Gamme min_Lab;
        //Gamme min_Mib;
        //Gamme min_Sib;
        //Gamme min_Fa;
        //Gamme min_Do;
        //Gamme min_Sol;
        //Gamme min_Re;
        //Gamme min_La;
        //Gamme min_Mi;
        //Gamme min_Si;
        //Gamme min_FaD;
        //Gamme min_DoD;
        //Gamme min_SolD;
        //Gamme min_ReD;
        //Gamme min_LaD;
        //Gamme min_MiD;



        #endregion


        #region Liste des notes à l'anglaise
        string[] tPitch_Maj;
        string[] tPitch_Min;
        #endregion

        #region Dictionnary
        Dictionary<string, Gamme> _DGammesMajeures;
        //Dictionary<string, Gamme> _DGammesMineures;

        Dictionary<string, string> dPitch_Maj;

        #endregion

        #region PROPRIETES
        public Dictionary<string, Gamme> DGammesMajeures { get => _DGammesMajeures; }
        public Gamme Maj_Fab { get => maj_Fab; set => maj_Fab = value; }
        public Gamme Maj_Dob { get => maj_Dob; set => maj_Dob = value; }
        public Gamme Maj_Solb { get => maj_Solb; set => maj_Solb = value; }
        public Gamme Maj_Reb { get => maj_Reb; set => maj_Reb = value; }
        public Gamme Maj_Lab { get => maj_Lab; set => maj_Lab = value; }
        public Gamme Maj_Mib { get => maj_Mib; set => maj_Mib = value; }
        public Gamme Maj_Sib { get => maj_Sib; set => maj_Sib = value; }
        public Gamme Maj_Fa { get => maj_Fa; set => maj_Fa = value; }
        public Gamme Maj_Do { get => maj_Do; set => maj_Do = value; }
        public Gamme Maj_Sol { get => maj_Sol; set => maj_Sol = value; }
        public Gamme Maj_Re { get => maj_Re; set => maj_Re = value; }
        public Gamme Maj_La { get => maj_La; set => maj_La = value; }
        public Gamme Maj_Mi { get => maj_Mi; set => maj_Mi = value; }
        public Gamme Maj_Si { get => maj_Si; set => maj_Si = value; }
        public Gamme Maj_FaD { get => maj_FaD; set => maj_FaD = value; }
        public Gamme Maj_DoD { get => maj_DoD; set => maj_DoD = value; }
        public Gamme Maj_SolD { get => maj_SolD; set => maj_SolD = value; }
        public Dictionary<string, string> DPitch_Maj { get => dPitch_Maj; set => dPitch_Maj = value; }

        #endregion

        public EnsembleGamme()
        {
            CreerNotes();

            CreerListesNotes();

            CreerGammes();

            #region Dictionnaires de Gammes et leur armature

            _DGammesMajeures = new Dictionary<string, Gamme>
            {
                 {"8b", maj_Fab },
                 {"7b", maj_Dob },
                 {"6b", maj_Solb },
                 {"5b", maj_Reb },
                 {"4b", maj_Lab },
                 {"3b", maj_Mib },
                 {"2b", maj_Sib },
                 {"1b", maj_Fa },

                 {"0", maj_Do },
                 {"1#", maj_Sol },
                 {"2#", maj_Re },
                 {"3#", maj_La },
                 {"4#", maj_Mi },
                 {"5#", maj_Si },
                 {"6#", maj_FaD },
                 {"7#", maj_DoD },
                 {"8#", maj_SolD },
            };

            #endregion


            // créer dictionnaire qui contient l'armature et l'équivalent en note anglais
            dPitch_Maj = new Dictionary<string, string>
            {
                {"8b", "" },
                 {"7b", "" },
                 {"6b", "" },
                 {"5b", "" },
                 {"4b", "" },
                 {"3b", "" },
                 {"2b", "Bb" },
                 {"1b", "F" },

                 {"0", "C" },
                 {"1#", "G" },
                 {"2#", "D" },
                 {"3#", "A" },
                 {"4#", "E" },
                 {"5#", "B" },
                 {"6#", "" },
                 {"7#", "" },
                 {"8#", "" },
            };
        }

        public void CreerNotes()
        {

            #region MaNotes   Remarque : les bémols vont jusqua Pitch.3 et pas 4 

            // Do
            SiD = new MaNote(Pitch.BSharp4, "Si#");
            Do = new MaNote(Pitch.C3, "Do");
            ReBB = new MaNote(Pitch.C3, "Re##");

            SiDD = new MaNote(Pitch.CSharp4, "Si##");
            DoD = new MaNote(Pitch.CSharp4, "Do#");
            ReB = new MaNote(Pitch.Db3, "Re♭");

            // Re
            DoDD = new MaNote(Pitch.D4, "Do##");
            Re = new MaNote(Pitch.D4, "Re");
            MiBB = new MaNote(Pitch.D4, "Mi♭♭");

            ReD = new MaNote(Pitch.DSharp4, "Re#");
            MiB = new MaNote(Pitch.Eb3, "Mi♭");
            FaBB = new MaNote(Pitch.Eb3, "Fa♭♭");

            // Mi
            ReDD = new MaNote(Pitch.E4, "Re##");
            Mi = new MaNote(Pitch.E4, "Mi");
            FaB = new MaNote(Pitch.Fb3, "Fa♭");

            // Fa
            MiD = new MaNote(Pitch.ESharp4, "Mi#");
            Fa = new MaNote(Pitch.F4, "Fa");
            SolBB = new MaNote(Pitch.F4, "Sol♭♭");

            MiDD = new MaNote(Pitch.FSharp4, "Mi##");
            FaD = new MaNote(Pitch.FSharp4, "Fa#");
            SolB = new MaNote(Pitch.Gb3, "Sol♭");

            // Sol
            FaDD = new MaNote(Pitch.G4, "Fa##");
            Sol = new MaNote(Pitch.G4, "Sol");
            LaBB = new MaNote(Pitch.G4, "La♭♭");

            FaDDD = new MaNote(Pitch.GSharp4, "Fa###");
            SolD = new MaNote(Pitch.GSharp4, "Sol#");
            LaB = new MaNote(Pitch.Ab3, "La♭");
            SiBBB = new MaNote(Pitch.Ab3, "Si♭♭♭");

            // La
            SolDD = new MaNote(Pitch.A4, "Sol##");
            La = new MaNote(Pitch.A4, "La");
            SiBB = new MaNote(Pitch.A4, "Si♭♭");

            DoBB = new MaNote(Pitch.ASharp4, "Do♭♭");
            LaD = new MaNote(Pitch.ASharp4, "La#");
            SiB = new MaNote(Pitch.Bb3, "Si♭");

            // Si
            LaDD = new MaNote(Pitch.B4, "La##");
            Si = new MaNote(Pitch.B4, "Si");
            DoB = new MaNote(Pitch.Cb3, "Do♭");


            #endregion

        }

        public void CreerListesNotes()
        {

            #region Liste<MaNote> Majeures
            // Gamme de Fab majeur ( 8b ) 
            LstGM_Fab = new List<MaNote>() { FaB, Fa, SolBB, SolB, Sol, LaBB, LaB, La, SiBBB, SiBB, SiB, DoBB, DoB, Do, ReBB, ReB, MiBB, MiB, Mi, FaBB };
            // Gamme de Dob majeur ( 7b ) 
            LstGM_Dob = new List<MaNote>() { DoB, Do, ReBB, ReB, Re, MiBB, MiB, Mi, FaBB, FaB, Fa, SolBB, SolB, Sol, LaBB, LaB, La, SiBB, SiB, Si, DoBB };
            // Gamme de Solb majeur ( 6b ) 
            LstGM_Solb = new List<MaNote>() { SolB, Sol, LaBB, LaB, La, SiBB, SiB, Si, DoBB, DoB, Do, ReBB, ReB, Re, MiBB, MiB, Mi, FaB, Fa, FaD, SolBB };

            // Gamme de Réb majeur ( 5b ) 
            LstGM_Reb = new List<MaNote>() { ReB, Re, MiBB, MiB, Mi, FaB, Fa, FaD, SolBB, SolB, Sol, LaBB, LaB, La, SiBB, SiB, Si, DoB, Do, DoD, ReBB };

            // Gamme de Lab majeur ( 4b ) 
            LstGM_Lab = new List<MaNote>() { LaB, La, SiBB, SiB, Si, DoB, Do, DoD, ReBB, ReB, Re, MiBB, MiB, Mi, FaB, Fa, FaD, SolB, Sol, SolD, LaBB };

            // Gamme de Mib majeur ( 3b ) 
            LstGM_Mib = new List<MaNote>() { MiB, Mi, FaB, Fa, FaD, SolB, Sol, SolD, LaBB, LaB, La, SiBB, SiB, Si, DoB, Do, DoD, ReB, Re, ReD, MiBB };

            // Gamme de Sib majeur ( 2b ) 
            LstGM_Sib = new List<MaNote>() { SiB, Si, DoB, Do, DoD, ReB, Re, ReD, MiBB, MiB, Mi, FaB, Fa, FaD, SolB, Sol, SolD, LaB, La, LaD, SiBB };

            // Gamme de Fa majeur ( 1b ) 
            LstGM_Fa = new List<MaNote>() { Fa, FaD, SolB, Sol, SolD, LaB, La, LaD, SiBB, SiB, Si, DoB, Do, DoD, ReB, Re, ReD, MiB, Mi, MiD, FaB };

            // Gamme de do majeur ( 0 ) 
            LstGM_Do = new List<MaNote>() { Do, DoD, ReB, Re, ReD, MiB, Mi, MiD, FaB, Fa, FaD, SolB, Sol, SolD, LaB, La, LaD, SiB, Si, SiD, DoB };

            // Gamme de sol majeur ( 1# ) 
            LstGM_Sol = new List<MaNote>() { Sol, SolD, LaB, La, LaD, SiB, Si, SiD, DoB, Do, DoD, ReB, Re, ReD, MiB, Mi, MiD, Fa, FaD, FaDD, SolB };

            // Gamme de ré majeur ( 2# ) 
            LstGM_Re = new List<MaNote>() { Re, ReD, MiB, Mi, MiD, Fa, FaD, FaDD, SolB, Sol, SolD, LaB, La, LaD, SiB, Si, SiD, Do, DoD, DoDD, ReB };

            // Gamme de la majeur ( 3# ) 
            LstGM_La = new List<MaNote>() { La, LaD, SiB, Si, SiD, Do, DoD, DoDD, ReB, Re, ReD, MiB, Mi, MiD, Fa, FaD, FaDD, Sol, SolD, SolDD, LaB };

            // Gamme de mi majeur ( 4# ) 
            LstGM_Mi = new List<MaNote>() { Mi, MiD, Fa, FaD, FaDD, Sol, SolD, SolDD, LaB, La, LaD, SiB, Si, SiD, Do, DoD, DoDD, Re, ReD, ReDD, MiB };

            // Gamme de si majeur ( 5# ) 
            LstGM_Si = new List<MaNote>() { Si, SiD, Do, DoD, DoDD, Re, ReD, ReDD, MiB, Mi, MiD, Fa, FaD, FaDD, Sol, SolD, SolDD, La, LaD, LaDD, SiB };

            // Gamme de Fa# majeur ( 6# ) 
            LstGM_FaD = new List<MaNote>() { FaD, FaDD, Sol, SolD, SolDD, La, LaD, LaDD, SiB, Si, SiD, Do, DoD, DoDD, Re, ReD, ReDD, Mi, MiD, MiDD, Fa };

            // Gamme de Do# majeur ( 7# ) 
            LstGM_DoD = new List<MaNote>() { DoD, DoDD, Re, ReD, ReDD, Mi, MiD, MiDD, Fa, FaD, FaDD, Sol, SolD, SolDD, La, LaD, LaDD, Si, SiD, SiDD, Do };

            // Gamme de Sol# majeur ( 8# ) 
            LstGM_SolD = new List<MaNote>() { SolD, SolDD, La, LaD, LaDD, Si, SiD, SiDD, Do, DoD, DoDD, Re, ReD, ReDD, Mi, MiD, MiDD, FaD, FaDD, FaDDD, Sol };
            #endregion

            #region List<MaNote> mineures
            ////Gmin_Reb = new List<MaNote>() { La, Si, DoD, Re, Mi, FaD, SolD };
            ////Gmin_Lab = new List<MaNote>() { La, Si, DoD, Re, Mi, FaD, SolD };

            //LstGmin_Mib = new List<MaNote>() { LaB, SiB,/* DoB,*/ ReB, MiB, Fa, SolB };
            //LstGmin_Sib = new List<MaNote>() { SiB, Do, ReB, MiB, Fa, SolB, LaB };
            //LstGmin_Fa = new List<MaNote>() { Fa, Sol, LaB, SiB, Do, ReB, MiB };
            //LstGmin_Do = new List<MaNote>() { Do, Re, MiB, Fa, Sol, LaB, SiB };
            //LstGmin_Sol = new List<MaNote>() { Sol, La, SiB, Do, Re, MiB, Fa };
            //LstGmin_Re = new List<MaNote>() { Re, Mi, Fa, Sol, La, SiB, Do, };

            //LstGmin_La = new List<MaNote>() { La, Si, Do, Re, Mi, Fa, Sol };

            //LstGmin_Mi = new List<MaNote>() { Mi, FaD, Sol, La, Si, Do, Re };
            //LstGmin_Si = new List<MaNote>() { Si, Do, Re, Mi, FaD, Sol, La };
            //LstGmin_FaD = new List<MaNote>() { FaD, SolD, La, Si, DoD, Re, Mi };
            //LstGmin_DoD = new List<MaNote>() { DoD, ReD, Mi, FaD, SolD, La, Si };
            //LstGmin_SolD = new List<MaNote>() { SolD, LaD, Si, DoD, ReD, Mi, FaD };

            ////Gmin_ReD = new List<MaNote>() { La, Si, DoD, Re, Mi, FaD, SolD };
            ////Gmin_LaD = new List<MaNote>() { La, Si, DoD, Re, Mi, FaD, SolD };
            ////Gmin_MiD = new List<MaNote>() { La, Si, DoD, Re, Mi, FaD, SolD };
            #endregion

        }

        public void CreerGammes()
        {
            #region Gammes majeures
            maj_Fab = new Gamme("Fa♭", LstGM_Fab);
            maj_Dob = new Gamme("Do♭", LstGM_Dob);
            maj_Solb = new Gamme("Sol♭", LstGM_Solb);
            maj_Reb = new Gamme("Re♭", LstGM_Reb);
            maj_Lab = new Gamme("La♭", LstGM_Lab);
            maj_Mib = new Gamme("Mi♭", LstGM_Mib);
            maj_Sib = new Gamme("Si♭", LstGM_Sib);
            maj_Fa = new Gamme("Fa", LstGM_Fa);
            maj_Do = new Gamme("Do", LstGM_Do);
            maj_Sol = new Gamme("Sol", LstGM_Sol);
            maj_Re = new Gamme("Re", LstGM_Re);
            maj_La = new Gamme("La", LstGM_La);
            maj_Mi = new Gamme("Mi", LstGM_Mi);
            maj_Si = new Gamme("Si", LstGM_Si);
            maj_FaD = new Gamme("Fa#", LstGM_FaD);
            maj_DoD = new Gamme("Do#", LstGM_DoD);
            maj_SolD = new Gamme("Sol#", LstGM_SolD);

            #endregion

            #region Gammes mineures
            ////  maj_Fab = new Gamme() changer
            //// maj_Dob = new Gamme() changer

            //min_Mib = new Gamme("Mi♭", LstGmin_Mib);
            //min_Sib = new Gamme("Si♭", LstGmin_Sib);
            //min_Fa = new Gamme("Fa", LstGmin_Fa);
            //min_Do = new Gamme("Do", LstGmin_Do);
            //min_Sol = new Gamme("Sol", LstGmin_Sol);
            //min_Re = new Gamme("Re", LstGmin_Re);

            //min_La = new Gamme("La", LstGmin_La);

            //min_Mi = new Gamme("Mi", LstGmin_Mi);
            //min_Si = new Gamme("Si", LstGmin_Si);
            //min_FaD = new Gamme("Fa♯", LstGmin_FaD);
            //min_DoD = new Gamme("Do♯", LstGmin_DoD);
            //min_SolD = new Gamme("Sol♯", LstGmin_SolD);

            ////maj_Fa = new Gamme("1b", GM_Fa);
            ////maj_Fa = new Gamme("1b", GM_Fa);
            ////maj_Fa = new Gamme("1b", GM_Fa);

            #endregion

        }

       
    }
}

