﻿using Manufaktura.Controls.Extensions;
using Manufaktura.Controls.Model;
using Manufaktura.Controls.Parser;
using Manufaktura.Controls.SMuFL;
using Manufaktura.Music.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Xml.Linq;


/*
*  Pour transposer on a besoin de :
*  la partition de départ
*  connaitre l'armature --> dans quelle gamme la partition est
*  connaitre dans quelle tonalité on veut transposer 
*  trouver chaque note dans la gamme de départ, et trouver la même position dans la gamme d'arrivée
*  afficher chaque note en partition
*/
namespace Test_mAN
{

    class Transposeur
    {
        /* Variables */

        private EnsembleGamme _infos;
        private Score _partitionDepart;

        // string armaturePartitionDepart = "";
        Gamme tonaliteTransposition;


        public Score PartitionDepart { get => _partitionDepart; set => _partitionDepart = value; }

        public Transposeur(Score partitionDépart)
        {
            _partitionDepart = partitionDépart;
        }

        public Transposeur()
        {
            _infos = new EnsembleGamme();
        }

        /// <summary>
        /// Permet de récupérer le nombre de b / # pour savoir dans quelle tonalité nous sommes avant la transposition
        /// Pour armature simple
        /// </summary>
        public Gamme TrouverTonaliteDeDepart(Pitch armature)
        {

            // Récupérer le nom caster Pitch en Step 
            string stepName = armature.StepName;
            string key = "";

            // Regarder si les notes en anglais correspondent 
            foreach (var note in _infos.DPitch_Maj)
            {
                // récupérer la clé de la valeur
                if (note.Value == stepName)
                {
                    key = note.Key;

                    foreach (var gamme in _infos.DGammesMajeures)
                    {
                        if (gamme.Key == key)
                        {
                            // Récupère la Gamme avec son nom et la liste des notes
                            tonaliteTransposition = gamme.Value;
                        }
                    }
                }

            }
            return tonaliteTransposition;
            // Formatter pour que ce soit sous la forme 1b, 3# etc..

            // Chercher dans le dictionnaire à quelle clé ça correspond --> récupérer la gamme correspondante
        }





        /// <summary>
        ///  Connaitre dans quelle tonalité l'utilisateur veut transposer (trouver la gamme correspondante)
        /// </summary>
        /// <param name="tonalite">Récupérer ce que l'utilisateur a choisi dans la liste déroulante</param>
        /// <returns></returns>
        public Gamme RecupererTonaliteDeTransposition(string tonalite)
        {

            // Formatter pour que ce soit sous la forme 1b, 3# etc..
            string[] split = tonalite.Split(' ');
            string armature = split[2];

            // Chercher dans le dictionnaire à quelle clé ça correspond --> récupérer la gamme correspondante
            foreach (var gamme in _infos.DGammesMajeures)
            {
                if (gamme.Key == armature)
                {
                    // Récupère la Gamme avec son nom et la liste des notes
                    tonaliteTransposition = gamme.Value;
                }
            }

            return tonaliteTransposition;
        }

        /// <summary>
        /// Transposer chaque note de la partition de départ en utilisant les gammes de références
        /// </summary>
        public void Transposer(string tonaliteArrive, Pitch armature)
        {
            TrouverTonaliteDeDepart(armature);

            RecupererTonaliteDeTransposition(tonaliteArrive);


            // parcourir la partition et récupérer les notes

            // parcourir la gamme de départ et trouver à quelle position est chaque note

            // Cette position est la même dans la gamme d'arrivée, il faut alors stocker la nouvelle note
        }

    }
}
