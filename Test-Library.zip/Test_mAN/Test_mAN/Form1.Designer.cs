﻿namespace Test_mAN
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.noteViewer1 = new Manufaktura.Controls.WinForms.NoteViewer();
            this.ckbMinor = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnTransposer = new System.Windows.Forms.Button();
            this.cmbGammes = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 117F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 118F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 114F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel1.Controls.Add(this.noteViewer1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.ckbMinor, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnTransposer, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.cmbGammes, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1622, 980);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // noteViewer1
            // 
            this.noteViewer1.DataSource = null;
            this.noteViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.noteViewer1.Location = new System.Drawing.Point(3, 3);
            this.noteViewer1.Name = "noteViewer1";
            this.noteViewer1.RenderingMode = Manufaktura.Controls.Rendering.ScoreRenderingModes.AllPages;
            this.noteViewer1.Size = new System.Drawing.Size(1166, 974);
            this.noteViewer1.TabIndex = 0;
            // 
            // ckbMinor
            // 
            this.ckbMinor.AutoSize = true;
            this.ckbMinor.Location = new System.Drawing.Point(1410, 3);
            this.ckbMinor.Name = "ckbMinor";
            this.ckbMinor.Size = new System.Drawing.Size(106, 17);
            this.ckbMinor.TabIndex = 3;
            this.ckbMinor.Text = "Relative Mineure";
            this.ckbMinor.UseVisualStyleBackColor = true;
            this.ckbMinor.CheckedChanged += new System.EventHandler(this.ckbMinor_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1175, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 31);
            this.button1.TabIndex = 4;
            this.button1.Text = "Open";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnTransposer
            // 
            this.btnTransposer.Location = new System.Drawing.Point(1524, 3);
            this.btnTransposer.Name = "btnTransposer";
            this.btnTransposer.Size = new System.Drawing.Size(95, 23);
            this.btnTransposer.TabIndex = 5;
            this.btnTransposer.Text = "Transposer";
            this.btnTransposer.UseVisualStyleBackColor = true;
            this.btnTransposer.Click += new System.EventHandler(this.btnTransposer_Click);
            // 
            // cmbGammes
            // 
            this.cmbGammes.FormattingEnabled = true;
            this.cmbGammes.Location = new System.Drawing.Point(1292, 3);
            this.cmbGammes.Name = "cmbGammes";
            this.cmbGammes.Size = new System.Drawing.Size(112, 21);
            this.cmbGammes.TabIndex = 2;
            this.cmbGammes.Text = "Gammes";
            this.cmbGammes.SelectedIndexChanged += new System.EventHandler(this.cmbGammes_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1622, 980);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Manufaktura.Controls.WinForms.NoteViewer noteViewer1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ComboBox cmbGammes;
        private System.Windows.Forms.CheckBox ckbMinor;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnTransposer;
    }
}

